#include "04supportwindow.h"
#include "ui_supportwindow.h"

SupportWindow::SupportWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SupportWindow)
{
    ui->setupUi(this);

}

SupportWindow::~SupportWindow()
{
    delete ui;
}

void SupportWindow::setBar(int value)
{
    ui->progressBar->setValue(value);
}
