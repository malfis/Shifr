#ifndef SUPPORTWINDOW_H
#define SUPPORTWINDOW_H

#include <QDialog>

namespace Ui {
class SupportWindow;
}

class SupportWindow : public QDialog
{
    Q_OBJECT

public:
    explicit SupportWindow(QWidget *parent = 0);
    ~SupportWindow();


    void setBar(int );

private:
    Ui::SupportWindow *ui;
};

#endif // SUPPORTWINDOW_H
