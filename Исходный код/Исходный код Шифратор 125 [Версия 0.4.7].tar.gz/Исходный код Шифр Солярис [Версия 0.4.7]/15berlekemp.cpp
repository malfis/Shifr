#include <QString>
void Berlekemp(QString binartext, QString *MatricaBerlekempa, int d, int k)
{


    int size_BoolMas=binartext.size();
    bool* BoolMas;
    BoolMas= new bool [size_BoolMas];
    QString odin_simbol;
    for (int i=0; i<size_BoolMas; i++)
    {
        odin_simbol=binartext.at(i);
        BoolMas[i]=odin_simbol.toInt();
    }


    //создание и заполнение полинома из массива байт
    PolinomM2 PolinomTest;
    PolinomTest.fromMasBitToPolinomM2(BoolMas,size_BoolMas);
    delete [] BoolMas;





    //Построение матрицы
    for (int i=k; i>=1; i--)
    {
        //получаем неприводимый многочлен
        QString buf;
        for (int v=2*i; v>=0; v--)
            if (v==i||v==2*i) buf+="1";
            else buf+="0";

        int size_BoolMas=buf.size();
        bool* BoolMas;
        BoolMas= new bool [size_BoolMas];
        QString odin_simbol;
        for (int y=0; y<size_BoolMas; y++)
        {
            odin_simbol=buf.at(y);
            BoolMas[y]=odin_simbol.toInt();
        }
        //создание и заполнение полинома из массива байт
        PolinomM2 PolinomBuf;
        PolinomBuf.fromMasBitToPolinomM2(BoolMas,size_BoolMas);
        delete [] BoolMas;

        if (PolinomBuf.getPolinomSize()>=k) PolinomBuf=PolinomBuf%PolinomTest;


        MatricaBerlekempa[k-i]="";
        for (int y=PolinomBuf.getPolinomSize(); y<=k; y++)
            MatricaBerlekempa[k-i]+="0";
        for (int y=0; y<PolinomBuf.getPolinomSize(); y++)
            MatricaBerlekempa[k-i]+=QString::number(PolinomBuf.getPolinom(y));
    }


    int sm=0;
    for (int n=0; n<d; n++)
    {
        int strok=0;
        int max=sm;
        for (int m=sm; m<k; m++)
        {
            if (MatricaBerlekempa[m].at(n)=='1')
            {
                strok++;
                for (int nn=sm; nn<d; nn++)
                {
                    QString simbol1, simbol2;
                    simbol1=MatricaBerlekempa[max].at(nn);
                    simbol2=MatricaBerlekempa[m].at(nn);
                    if (simbol1.toInt()>simbol2.toInt()) nn=d;
                    if (simbol1.toInt()<simbol2.toInt())
                    {
                        max=m;
                        nn=d;
                    }
                }
            }
        }

        if (sm<k)
        {
            QString buf=MatricaBerlekempa[sm];
            MatricaBerlekempa[sm]=MatricaBerlekempa[max];
            MatricaBerlekempa[max]=buf;
        }


        for (int s=1; s<strok; s++)
        {
            for (int m=sm+1; m<k; m++)
            {
                if (MatricaBerlekempa[m].at(n)=='1')
                {
                    for (int nn=sm; nn<d; nn++)
                    {
                        QString simbol1, simbol2;
                        simbol1=MatricaBerlekempa[sm].at(nn);
                        simbol2=MatricaBerlekempa[m].at(nn);
                        if (simbol1.toInt()==simbol2.toInt()) MatricaBerlekempa[m].replace(nn,1,"0");
                        if (simbol1.toInt()>simbol2.toInt()) MatricaBerlekempa[m].replace(nn,1,"1");
                    }
                }
            }
        }


        if (strok!=0) sm++;
    }
}
