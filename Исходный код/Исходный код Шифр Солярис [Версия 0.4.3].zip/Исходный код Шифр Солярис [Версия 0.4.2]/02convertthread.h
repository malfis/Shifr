#ifndef CONVERTTHREAD_H
#define CONVERTTHREAD_H
#include "01mainwindow.h"
#include "QThread"


class ConvertThread: public QObject
{
    Q_OBJECT


public:
    explicit ConvertThread(QWidget *parent = 0);
    ~ConvertThread();


    bool exit;
    MainWindow *ui;

private:


signals:
    void setProgressBar(int , QString );
    void file_exit(QString );

    void resultTestFile(QString );


private slots:
    void file_shifr(QString );
    void file_rasshifr(QString );

    void startTestFile(QString );


};

#endif // CONVERTTHREAD_H
