#ifndef COMBOSEGMENT_H
#define COMBOSEGMENT_H

#include "01mainwindow.h"

class ComboSegment : public QSpinBox
{
    Q_OBJECT
public:
    explicit ComboSegment(QWidget *parent = 0);
    ~ComboSegment();

    MainWindow *ui;


private slots:

    void redacktirovanieSegmentov (int );


private:


};



#endif // COMBOSEGMENT_H
//-------------------------------------------------------------------------

#ifndef COMBOSEGMENTK_H
#define COMBOSEGMENTK_H


#include "01mainwindow.h"

class ComboSegmentK : public QSpinBox
{
    Q_OBJECT
public:
    explicit ComboSegmentK(QWidget *parent = 0);
    ~ComboSegmentK();

    MainWindow *ui;



private slots:

    void redacktirovanieSegmentov (int );


private:


};


#endif // COMBOSEGMENTK_H
//-------------------------------------------------------------------------

#ifndef SPINSEGMENT_H
#define SPINSEGMENT_H

#include "01mainwindow.h"

class SpinSegment : public QSpinBox
{
    Q_OBJECT
public:
    explicit SpinSegment(QWidget *parent = 0);
    ~SpinSegment();

    MainWindow *ui;


private slots:

    void redacktirovanieSegmentov (int );


private:


};

#endif // SPINSEGMENT_H
//-------------------------------------------------------------------------

#ifndef SPINSEGMENTK_H
#define SPINSEGMENTK_H


#include "01mainwindow.h"

class SpinSegmentK : public QSpinBox
{
    Q_OBJECT
public:
    explicit SpinSegmentK(QWidget *parent = 0);
    ~SpinSegmentK();

    MainWindow *ui;


private slots:

    void redacktirovanieSegmentov (int );


private:


};

#endif // SPINSEGMENTK_H
//-------------------------------------------------------------------------

#ifndef SPINSEGMENTN_H
#define SPINSEGMENTN_H


#include "01mainwindow.h"

class SpinSegmentN : public QSpinBox
{
    Q_OBJECT
public:
    explicit SpinSegmentN(QWidget *parent = 0);
    ~SpinSegmentN();

    MainWindow *ui;


private slots:

    void redacktirovanieSegmentov (int );


private:


};

#endif // SPINSEGMENTN_H
//-------------------------------------------------------------------------

#ifndef SPINSEGMENTRK_H
#define SPINSEGMENTRK_H


#include "01mainwindow.h"

class SpinSegmentRK : public QSpinBox
{
    Q_OBJECT
public:
    explicit SpinSegmentRK(QWidget *parent = 0);
    ~SpinSegmentRK();

    MainWindow *ui;


private slots:

    void redacktirovanieSegmentov (int );


private:


};

#endif // SPINSEGMENTRK_H

