#include "05segments.h"


ComboSegment::ComboSegment(QWidget *parent):
    QSpinBox (parent)
{
    ui=NULL;
    connect(this , SIGNAL(valueChanged(int)),this,SLOT(redacktirovanieSegmentov(int)));
}

ComboSegment::~ComboSegment()
{

}

void ComboSegment::redacktirovanieSegmentov (int )
{
    if (ui!=NULL) ui->updatePage(this->value());
}
//-------------------------------------------------------------------------

ComboSegmentK::ComboSegmentK(QWidget *parent):
    QSpinBox (parent)
{
    ui=NULL;
    connect(this , SIGNAL(valueChanged(int)),this,SLOT(redacktirovanieSegmentov(int)));
}

ComboSegmentK::~ComboSegmentK()
{

}

void ComboSegmentK::redacktirovanieSegmentov (int )
{
    if (ui!=NULL) ui->updatePageK(this->value());
}
//-------------------------------------------------------------------------


SpinSegment::SpinSegment(QWidget *parent):
    QSpinBox (parent)
{
    ui=NULL;
    connect(this , SIGNAL(valueChanged(int)),this,SLOT(redacktirovanieSegmentov(int)));
}

SpinSegment::~SpinSegment()
{

}

void SpinSegment::redacktirovanieSegmentov (int )
{
    if (ui!=NULL) ui->updateZameny();
}

//-------------------------------------------------------------------------


SpinSegmentK::SpinSegmentK(QWidget *parent):
    QSpinBox (parent)
{
    ui=NULL;
    connect(this , SIGNAL(valueChanged(int)),this,SLOT(redacktirovanieSegmentov(int)));
}

SpinSegmentK::~SpinSegmentK()
{

}

void SpinSegmentK::redacktirovanieSegmentov (int )
{
    if (ui!=NULL) ui->updateKey();
}

//-------------------------------------------------------------------------


SpinSegmentN::SpinSegmentN(QWidget *parent):
    QSpinBox (parent)
{
    ui=NULL;
    connect(this , SIGNAL(valueChanged(int)),this,SLOT(redacktirovanieSegmentov(int)));
}

SpinSegmentN::~SpinSegmentN()
{

}

void SpinSegmentN::redacktirovanieSegmentov (int )
{
    if (ui!=NULL) ui->updateNomer();
}

//-------------------------------------------------------------------------

SpinSegmentRK::SpinSegmentRK(QWidget *parent):
    QSpinBox (parent)
{
    ui=NULL;
    connect(this , SIGNAL(valueChanged(int)),this,SLOT(redacktirovanieSegmentov(int)));
}

SpinSegmentRK::~SpinSegmentRK()
{

}

void SpinSegmentRK::redacktirovanieSegmentov (int )
{
    if (ui!=NULL) ui->updateRayndKey();
}

