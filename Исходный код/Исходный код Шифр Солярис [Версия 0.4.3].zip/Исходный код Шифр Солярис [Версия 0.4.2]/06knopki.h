#ifndef KNOPKAGENAK_H
#define KNOPKAGENAK_H


#include "01mainwindow.h"

class KnopkaGenaK : public QPushButton
{
    Q_OBJECT
public:
    explicit KnopkaGenaK(QWidget *parent = 0);
    ~KnopkaGenaK();

    MainWindow *ui;

private slots:

    void Generate (bool );


private:


};

#endif // KNOPKAGENAK_H
//-------------------------------------------------------------------------
#ifndef KNOPKAGENAZ_H
#define KNOPKAGENAZ_H

#include "01mainwindow.h"

class KnopkaGenaZ : public QPushButton
{
    Q_OBJECT
public:
    explicit KnopkaGenaZ(QWidget *parent = 0);
    ~KnopkaGenaZ();

    MainWindow *ui;

private slots:

    void Generate (bool );


private:


};

#endif // KNOPKAGENAZ_H
//-------------------------------------------------------------------------
#ifndef KNOPKASMENA_H
#define KNOPKASMENA_H

#include "01mainwindow.h"

class KnopkaSmena : public QPushButton
{
    Q_OBJECT
public:
    explicit KnopkaSmena(QWidget *parent = 0);
    ~KnopkaSmena();

    MainWindow *ui;

private slots:

    void Smena (bool );


private:


};

#endif // KNOPKASMENA_H
