#include "01mainwindow.h"
#include "05segments.h"
#include <QFileDialog>
#include <QTextStream>


void MainWindow::on_pushButton_8_clicked()
{
    QString buf="";
    QTime midnight(0,0,0);
    qsrand(midnight.msecsTo(QTime::currentTime()));
    for (int i=0; i<5040; i++)
    {
        buf+=QString::number(qrand()%2);
    }
    int kol_vo_rayndov = ui->spinBox->value();
    ui->plainTextEdit_2->setPlainText(buf.left(240*kol_vo_rayndov));
}


void MainWindow::on_pushButton_11_clicked()
{
    QString buf="";
    QTime midnight(0,0,0);
    qsrand(midnight.msecsTo(QTime::currentTime()));
    for (int i=0; i<240; i++)
    {
        buf+=QString::number(qrand()%2);
    }
    ui->plainTextEdit_8->setPlainText(buf);
}


void MainWindow::on_pushButton_3_clicked()
{
    if (up.tryLock())
    {
        this->hide();
        okno->showNormal();
        this->setEnabled(false);

        int kolvo_rayndov = ui->spinBox->text().toInt();
        QTime midnight(0,0,0);
        qsrand(midnight.msecsTo(QTime::currentTime()));
        double vpd_chast=(double) 50/kolvo_rayndov;
        double sum=0;
        for (int i=0; i<kolvo_rayndov; i++)
        {
            ui->tabWidget->setCurrentIndex(i);


            int ver=qrand()%100+1;
            int segmentov=1;
            if (ver>(100-p3)) segmentov=(qrand()%(md-rd))+rd;
            if ((ver>p1)&&(ver<=(100-p3))) segmentov=(qrand()%(rd-ld))+ld;
            if (ver<=p1) segmentov=(qrand()%(ld-nd))+nd;


            updatePage(segmentov);



            if (gen3.tryLock())
            {
                segment_zamen[i]->setValue(segmentov);
                gen3.unlock();
            }
            smesch_zamen[i]->setValue((qrand()%240)+1);

            //случайные числа для сегментов замен
            sum+=vpd_chast;
            okno->setBar(sum);
            QApplication::processEvents();
            ZamenaSegmentGen(segmentov);

            ver=qrand()%100+1;
            if (ver>(100-p3)) segmentov=(qrand()%(md-rd))+rd;
            if ((ver>p1)&&(ver<=(100-p3))) segmentov=(qrand()%(rd-ld))+ld;
            if (ver<=p1) segmentov=(qrand()%(ld-nd))+nd;


            updatePageK(segmentov);


            if (gen6.tryLock())
            {
                segment_key[i]->setValue(segmentov);
                gen6.unlock();
            }


            //случайные числа для сегментов ключа
            sum+=vpd_chast;
            okno->setBar(sum);
            QApplication::processEvents();
            KeySegmentGen(segmentov);


        }


        ui->tabWidget->setCurrentIndex(0);
        ui->pushButton_8->clicked();




        QMutex wait;
        wait.lock();
        wait.tryLock(100);
        wait.unlock();

        this->setEnabled(true);
        on_tabWidget_currentChanged(0);
        okno->close();
        this->show();

        up.unlock();
    }
}


void MainWindow::ZamenaSegmentGen(int segmentov)
{

    //Присвоение первичных случайных чисел до заполнения балансировки
    //Подсчет количества измененных сегментов (доноры в дальнейшем)
    bool *zapolnenie=new bool [segmentov];
    for (int k=0; k<segmentov; k++) zapolnenie[k]=false;
    int buf_segmentov=segmentov;
    //сколько можем раздать
    int bvs=240-segmentov+1;

    //Формируем случайный набор параметров с резкими перепадами значений
    //И большим количеством сегментов мелкой фрагментации
    for (int j=0; j<segmentov; j++)
    {
        int shagov=qrand()%buf_segmentov;
        int tek_segment=-1;
        for (int m=-1; m<shagov; m++)
        {
            tek_segment++;
            if (zapolnenie[tek_segment]) m--;
        }

        zapolnenie[tek_segment]=true;


        int tek_bvs=0;
        if (j==segmentov-1) tek_bvs=bvs;
        else tek_bvs=qrand()%bvs+1;

        mas_of_spinbox_zamen[nomer_raynda][tek_segment]->setValue(tek_bvs);

        bvs=bvs-tek_bvs+1;

        buf_segmentov--;
    }
    delete [] zapolnenie;






    //уменьшение повторений фрагментаций
    //фильтрайия не больше количества полиномов по степени
    //случайное сглаживание перепадов значений сегментов

    for (int pvr=0; pvr<b2; pvr++)
    {

        //Выставляем возможность случайного повторения блоков
        //не большую количества полиномов в БД
        int edinic=0;
        //Повторений не больше количества полиномов
        if (pvr>0) edinic=kolvo_polinom[pvr];



        //Пересчитываем количество значений уровня фильтра,
        //Для сравнения с порогом допустимого количества значений на данный уровень
        int kolvo_segmentov_edinic=0;
        for (int k=0; k<segmentov; k++)
            if (mas_of_spinbox_zamen[nomer_raynda][k]->value()==pvr+1)
                kolvo_segmentov_edinic++;

        //Определяем количество доступных доноров
        int kolvo_segmentov_donorov=0;
        for (int y=0; y<segmentov; y++)
        {
            if (mas_of_spinbox_zamen[nomer_raynda][y]->value()>(pvr+1)*2)
                kolvo_segmentov_donorov++;
        }

        while (kolvo_segmentov_edinic>edinic&&
               kolvo_segmentov_donorov>0)
        {

            int proxod=kolvo_segmentov_edinic;
            if (kolvo_segmentov_edinic>kolvo_segmentov_donorov) proxod=kolvo_segmentov_donorov;
            for (int rt=0; rt<proxod; rt++)
            {

                //Случайно определяем первого донора
                int nomer_segmenta_donora=qrand()%kolvo_segmentov_donorov+1;
                int ch=0;
                int segment_donora=0;
                //Ищем донора в параметрах, зная только информацию о количестве доноров
                //Останавливаемся только на доноре в порядке случайного номера, которое получено раннее.
                //Отличаем донора от других параметров по значению, которое должно быть больше фильтруемого
                for (int t=0; t<segmentov; t++)
                {
                    if (mas_of_spinbox_zamen[nomer_raynda][t]->value()>(pvr+1)*2) ch++;
                    if (ch==nomer_segmenta_donora)
                    {
                        segment_donora=t;
                        t=segmentov;
                    }
                }


                //Аналогично, определяем случайного реципиента
                //Значение реципиента должно быть равно фильтруемому
                int nomer_segmenta_edinic=qrand()%kolvo_segmentov_edinic+1;
                int ch2=0;
                int segment_edinic=0;
                for (int t=0; t<segmentov; t++)
                {
                    if (mas_of_spinbox_zamen[nomer_raynda][t]->value()==pvr+1) ch2++;
                    if (ch2==nomer_segmenta_edinic)
                    {
                        segment_edinic=t;
                        t=segmentov;
                    }
                }


                //Процедура заимствования, не должны оставить значение в доноре меньше фильтруемого уровня
                int bvs2=mas_of_spinbox_zamen[nomer_raynda][segment_donora]->value()-(pvr+2);
                int zaim=0;
                if (bvs2!=1) zaim=1+qrand()%(bvs2-1);
                else zaim=1;

                mas_of_spinbox_zamen[nomer_raynda][segment_donora]->setValue(
                            mas_of_spinbox_zamen[nomer_raynda][segment_donora]->value()-zaim);
                mas_of_spinbox_zamen[nomer_raynda][segment_edinic]->setValue(
                            mas_of_spinbox_zamen[nomer_raynda][segment_edinic]->value()+zaim);
                kolvo_segmentov_edinic--;

                kolvo_segmentov_donorov=0;
                //Определяем количество доступных доноров
                for (int y=0; y<segmentov; y++)
                {
                    if (mas_of_spinbox_zamen[nomer_raynda][y]->value()>(pvr+1)*2)
                        kolvo_segmentov_donorov++;
                }
                if (kolvo_segmentov_edinic>kolvo_segmentov_donorov) proxod=kolvo_segmentov_donorov;
            }
        }
    }




    //выбор номера полинома
    for (int j=0; j<segmentov; j++)
    {
        int nomer=qrand()%mas_of_combobox_zamen[nomer_raynda][j]->maximum()+1;
        if (nomer==0) nomer++;
        mas_of_combobox_zamen[nomer_raynda][j]->setValue(nomer);
    }

}


void MainWindow::KeySegmentGen(int segmentov)
{

    bool *zapolnenie=new bool [segmentov];
    for (int k=0; k<segmentov; k++) zapolnenie[k]=false;
    int buf_segmentov=segmentov;
    //сколько можем раздать
    int bvs=240-segmentov+1;


    //Формируем случайный набор параметров с резкими перепадами значений
    //И большим количеством сегментов мелкой фрагментации
    for (int j=0; j<segmentov; j++)
    {
        int shagov=qrand()%buf_segmentov;
        int tek_segment=-1;
        for (int m=-1; m<shagov; m++)
        {
            tek_segment++;
            if (zapolnenie[tek_segment]) m--;
        }

        zapolnenie[tek_segment]=true;


        int tek_bvs=0;
        if (j==segmentov-1) tek_bvs=bvs;
        else tek_bvs=qrand()%bvs+1;

        mas_of_spinbox_key[nomer_raynda][tek_segment]->setValue(tek_bvs);

        bvs=bvs-tek_bvs+1;

        buf_segmentov--;
    }
    delete [] zapolnenie;






    //уменьшение повторений фрагментаций
    //фильтрайия не больше количества полиномов по степени
    //случайное сглаживание перепадов значений сегментов

    for (int pvr=0; pvr<b2; pvr++)
    {
        //Выставляем возможность случайного повторения блоков
        //не большую количества полиномов в БД
        int edinic=0;
        //Повторений не больше количества полиномов
        if (pvr>0) edinic=kolvo_polinom[pvr];


        //Пересчитываем количество значений уровня фильтра,
        //Для сравнения с порогом допустимого количества значений на данный уровень
        int kolvo_segmentov_edinic=0;
        for (int k=0; k<segmentov; k++)
            if (mas_of_spinbox_key[nomer_raynda][k]->value()==pvr+1)
                kolvo_segmentov_edinic++;


        //Определяем количество доступных доноров
        int kolvo_segmentov_donorov=0;
        for (int y=0; y<segmentov; y++)
        {
            if (mas_of_spinbox_key[nomer_raynda][y]->value()>(pvr+1)*2)
                kolvo_segmentov_donorov++;
        }


        while (kolvo_segmentov_edinic>edinic&&
               kolvo_segmentov_donorov>0)
        {

            int proxod=kolvo_segmentov_edinic;
            if (kolvo_segmentov_edinic>kolvo_segmentov_donorov) proxod=kolvo_segmentov_donorov;
            for (int rt=0; rt<proxod; rt++)
            {
                int nomer_segmenta_donora=qrand()%kolvo_segmentov_donorov+1;
                int ch=0;
                int segment_donora=0;
                //Ищем донора в параметрах, зная только информацию о количестве доноров
                //Останавливаемся только на доноре в порядке случайного номера, которое получено раннее.
                //Отличаем донора от других параметров по значению, которое должно быть больше фильтруемого
                for (int t=0; t<segmentov; t++)
                {
                    if (mas_of_spinbox_key[nomer_raynda][t]->value()>(pvr+1)*2) ch++;
                    if (ch==nomer_segmenta_donora)
                    {
                        segment_donora=t;
                        t=segmentov;
                    }
                }


                //Аналогично, определяем случайного реципиента
                //Значение реципиента должно быть равно фильтруемому
                int nomer_segmenta_edinic=qrand()%kolvo_segmentov_edinic+1;
                int ch2=0;
                int segment_edinic=0;
                for (int t=0; t<segmentov; t++)
                {
                    if (mas_of_spinbox_key[nomer_raynda][t]->value()==pvr+1) ch2++;
                    if (ch2==nomer_segmenta_edinic)
                    {
                        segment_edinic=t;
                        t=segmentov;
                    }
                }


                //Процедура заимствования, не должны оставить значение в доноре меньше фильтруемого уровня
                int bvs2=mas_of_spinbox_key[nomer_raynda][segment_donora]->value()-(pvr+2);
                int zaim=0;
                if (bvs2!=1) zaim=1+qrand()%(bvs2-1);
                else zaim=1;


                mas_of_spinbox_key[nomer_raynda][segment_donora]->setValue(
                            mas_of_spinbox_key[nomer_raynda][segment_donora]->value()-zaim);
                mas_of_spinbox_key[nomer_raynda][segment_edinic]->setValue(
                            mas_of_spinbox_key[nomer_raynda][segment_edinic]->value()+zaim);
                kolvo_segmentov_edinic--;

                kolvo_segmentov_donorov=0;
                //Определяем количество доступных доноров
                for (int y=0; y<segmentov; y++)
                {
                    if (mas_of_spinbox_key[nomer_raynda][y]->value()>(pvr+1)*2)
                        kolvo_segmentov_donorov++;
                }
                if (kolvo_segmentov_edinic>kolvo_segmentov_donorov) proxod=kolvo_segmentov_donorov;
            }
        }
    }

}

void MainWindow::on_pushButton_9_clicked()
{
    ui->stackedWidget_3->setCurrentIndex(0);
}

void MainWindow::on_pushButton_10_clicked()
{
    ui->stackedWidget_3->setCurrentIndex(1);
}

void MainWindow::on_spinBox_3_valueChanged(int arg1)
{
    if (arg1>=ui->spinBox_4->value()) ui->spinBox_4->setValue(arg1+1);
    if (arg1<=ui->spinBox_8->value()) ui->spinBox_8->setValue(arg1-1);



    nd=ui->spinBox_8->value();
    ld=ui->spinBox_3->value();
    rd=ui->spinBox_4->value();
    md=ui->spinBox_9->value();
}

void MainWindow::on_spinBox_4_valueChanged(int arg1)
{
    if (arg1<=ui->spinBox_3->value()) ui->spinBox_3->setValue(arg1-1);
    if (arg1>=ui->spinBox_9->value()) ui->spinBox_9->setValue(arg1+1);




    nd=ui->spinBox_8->value();
    ld=ui->spinBox_3->value();
    rd=ui->spinBox_4->value();
    md=ui->spinBox_9->value();
}

void MainWindow::on_spinBox_8_valueChanged(int arg1)
{
    if (arg1>=ui->spinBox_3->value()) ui->spinBox_3->setValue(arg1+1);



    nd=ui->spinBox_8->value();
    ld=ui->spinBox_3->value();
    rd=ui->spinBox_4->value();
    md=ui->spinBox_9->value();
}

void MainWindow::on_spinBox_9_valueChanged(int arg1)
{
    if (arg1<=ui->spinBox_4->value()) ui->spinBox_4->setValue(arg1-1);



    nd=ui->spinBox_8->value();
    ld=ui->spinBox_3->value();
    rd=ui->spinBox_4->value();
    md=ui->spinBox_9->value();
}

void MainWindow::on_spinBox_5_valueChanged(int arg1)
{
    if (arg1+ui->spinBox_7->value()>100)
        ui->spinBox_5->setValue(100-ui->spinBox_7->value());
    else ui->spinBox_6->setValue(100-arg1-ui->spinBox_7->value());

    p1=ui->spinBox_5->value();
    p3=ui->spinBox_7->value();
}

void MainWindow::on_spinBox_7_valueChanged(int arg1)
{
    if (arg1+ui->spinBox_5->value()>100)
        ui->spinBox_7->setValue(100-ui->spinBox_5->value());
    else ui->spinBox_6->setValue(100-arg1-ui->spinBox_5->value());

    p1=ui->spinBox_5->value();
    p3=ui->spinBox_7->value();
}

void MainWindow::on_spinBox_10_valueChanged(int arg1)
{
    b2=arg1;
}

void MainWindow::on_pushButton_6_clicked()
{

    if (stop.tryLock())
    {
        this->setEnabled(false);

        bool balance_error=false;
        for (int i=0; i<ui->spinBox->value(); i++)
            if (balance_zamen[i]->text()!="Балансировка: 0"||
                    balance_key[i]->text()!="Балансировка: 0")
            {
                balance_error=true;
                i=ui->spinBox->value();
            }
        if (balance_error)
        {
            ui->plainTextEdit_6->setPlainText("Ошибка разбалансировки!");
            stop.unlock();
            this->setEnabled(true);;
            return;
        }

        QString filekey="";

        //Количество раундов
        filekey+=QString::number(ui->spinBox->value())+"|||";
        for (int r=0; r<ui->spinBox->value(); r++)
        {
            filekey+="  "+QString::number(r+1)+"|| ";

            //Параметры замены
            filekey+=QString::number(segment_zamen[r]->value())+"Z|";
            for (int z=0; z<segment_zamen[r]->value(); z++)
            {
                filekey+=QString::number(mas_of_spinbox_zamen[r][z]->value())+" ";

                if (mas_of_spinbox_zamen[r][z]->value()==1)
                    if (id_polinoma_na_segment[r][z]==2) filekey+="2 |";
                    else filekey+="1 |";
                else
                {
                    filekey+=QString::number(mas_of_combobox_zamen[r][z]->value())+" ";

                    for (int n=0; n<mas_polinomov[id_polinoma_na_segment[r][z]-1].getPolinomSize(); n++)
                        filekey+=QString::number(mas_polinomov[id_polinoma_na_segment[r][z]-1].getPolinom(n));
                    filekey+="|";
                }
            }


            //Параметры ключа
            filekey+=" "+QString::number(kol_vo_segmentov_key[r])+"K|";
            for (int k=0; k<kol_vo_segmentov_key[r]; k++)
            {
                filekey+=QString::number(mas_of_spinbox_key[r][k]->value())+" ";
            }
            filekey=filekey.left(filekey.length()-1)+"|";

            //Смещение блока
            filekey+=" "+QString::number(smesch_zamen[r]->value())+" ";
            //Смещение общего ключа
            filekey+=QString::number(smesch_key[r]->value())+" ";

        }

        //Общий ключ
        if (ui->plainTextEdit_2->toPlainText().length()==0) filekey+="0";
        else filekey+=ui->plainTextEdit_2->toPlainText();


        //Режим сцепки
        if (ui->checkBox_7->isChecked()) filekey+=" yes";
        else filekey+=" no";


        //Создание файла ключа и запись
        cur.remove(cur.lastIndexOf("/")+1,cur.length()-cur.lastIndexOf("/")-1);
        cur=QFileDialog::getSaveFileName(this,"Сохранение Общего Ключа (ОК) шифра Солярис", cur+"OKeySolaris",
                                         "Ждаки (*.zhdak);;"
                                         "Все файлы (*)");


        if(cur!="")
        {
            QFile file(cur);
            if (file.open(QIODevice::WriteOnly))
            {
                QTextStream potok_v_file(&file);
                potok_v_file<<filekey;
                file.close();
            }
        }


        stop.unlock();
        this->setEnabled(true);
    }
}

void MainWindow::on_pushButton_7_clicked()
{
    if (up.tryLock())
    {
        this->setEnabled(false);

        cur.remove(cur.lastIndexOf("/")+1,cur.length()-cur.lastIndexOf("/")-1);
        cur=QFileDialog::getOpenFileName(this,"Откройте файл Общего Ключа (ОК) шифра Солярис",cur,
                                         "Ждаки (*.zhdak);;"
                                         "Все файлы (*)");
        if(cur!="")
        {

            QFile file(cur);
            if (file.open(QIODevice::ReadOnly))
            {
                //подсчет количества многочленов
                for (int i=0; i<240; i++) kolvo_polinom[i]=0;

                QTextStream TextPotok(&file);
                QString str="";
                //Получение раунда
                TextPotok>>str;
                str=str.left(str.length()-3);
                int kolvo_rayndov = str.toInt();
                on_spinBox_valueChanged(kolvo_rayndov);
                if (gen7.tryLock())
                {
                    ui->spinBox->setValue(kolvo_rayndov);
                    gen7.unlock();
                }



                for (int r=0; r<kolvo_rayndov; r++)
                {

                    ui->tabWidget->setCurrentIndex(r);

                    //Параметры замены
                    TextPotok>>str;
                    TextPotok>>str;
                    QString segment;
                    segment=str.left(str.lastIndexOf("Z"));


                    updatePage(segment.toInt());
                    if (gen3.tryLock())
                    {
                        segment_zamen[r]->setValue(segment.toInt());
                        gen3.unlock();
                    }



                    QString buf;
                    for (int z=0; z<segment.toInt(); z++)
                    {
                        buf=str.right(str.length()-str.lastIndexOf("|")-1);
                        mas_of_spinbox_zamen[r][z]->setValue(buf.toInt());
                        TextPotok>>str;
                        mas_of_combobox_zamen[r][z]->setValue(str.toInt());
                        TextPotok>>str;
                    }


                    //Параметры ключа
                    TextPotok>>str;
                    segment=str.left(str.lastIndexOf("K"));



                    updatePageK(segment.toInt());
                    if (gen6.tryLock())
                    {
                        segment_key[r]->setValue(segment.toInt());
                        gen6.unlock();
                    }


                    if (segment.toInt()>1)
                    {
                        buf=str.right(str.length()-str.lastIndexOf("|")-1);
                        mas_of_spinbox_key[r][0]->setValue(buf.toInt());
                        for (int z=1; z<segment.toInt()-1; z++)
                        {
                            TextPotok>>str;
                            mas_of_spinbox_key[r][z]->setValue(str.toInt());
                        }
                        TextPotok>>str;
                        buf=str.left(str.lastIndexOf("|"));
                        mas_of_spinbox_key[r][segment.toInt()-1]->setValue(buf.toInt());
                    }

                    //Смещение блока и ключа
                    TextPotok>>str;
                    smesch_zamen[r]->setValue(str.toInt());
                    TextPotok>>str;
                    smesch_key[r]->setValue(str.toInt());

                }
                TextPotok>>str;
                ui->plainTextEdit_2->setPlainText(str);

                TextPotok>>str;
                if (str=="yes") ui->checkBox_7->setChecked(true);
                if (str=="no") ui->checkBox_7->setChecked(false);


                ui->tabWidget->setCurrentIndex(0);
            }
        }
        this->setEnabled(true);
        up.unlock();
    }
}

