#!/bin/sh
# полный путь до скрипта
ABSOLUTE_FILENAME=`readlink -e "$0"`
# каталог в котором лежит скрипт
DIRECTORY=`dirname "$ABSOLUTE_FILENAME"`
# прописываем переменные окружения для доступа к библиотекам из папки
export LD_LIBRARY_PATH="$DIRECTORY/QLib"
export QT_QPA_PLATFORM_PLUGIN_PATH="$DIRECTORY/QLib"
# запуск программы
chmod +x "$DIRECTORY"/Shifrator125
"$DIRECTORY"/Shifrator125